from django.shortcuts import render

from personal_info.models import PortfolioManage
from portfolio_about.models import AboutSection, Skill
from portfolio_site_resume.models import SiteResume


def home_page(request):
    siteresume: SiteResume = SiteResume.objects.all()
    about: AboutSection = AboutSection.objects.first()
    portfolio: PortfolioManage = PortfolioManage.objects.first()
    skills = Skill.objects.all()
    context = {
        'portfolio': portfolio,
        'about': about,
        'skills': skills,
        'siteresume': siteresume,
    }
    return render(request, 'home_page.html', context)

