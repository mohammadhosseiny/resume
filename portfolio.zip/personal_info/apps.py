from django.apps import AppConfig


class PersonalInfoConfig(AppConfig):
    name = 'personal_info'
