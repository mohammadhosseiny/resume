from django.shortcuts import render

# Create your views here.
from personal_info.models import PortfolioManage

