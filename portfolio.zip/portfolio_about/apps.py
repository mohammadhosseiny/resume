from django.apps import AppConfig


class PortfolioAboutConfig(AppConfig):
    name = 'portfolio_about'
