from django.contrib import admin

# Register your models here.
from portfolio_about.models import AboutSection, Skill

admin.site.register(AboutSection)

admin.site.register(Skill)
