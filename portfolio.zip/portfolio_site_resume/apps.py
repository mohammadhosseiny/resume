from django.apps import AppConfig


class PortfolioSiteResumeConfig(AppConfig):
    name = 'portfolio_site_resume'
