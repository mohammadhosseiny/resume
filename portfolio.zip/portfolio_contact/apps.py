from django.apps import AppConfig


class PortfolioContactConfig(AppConfig):
    name = 'portfolio_contact'
